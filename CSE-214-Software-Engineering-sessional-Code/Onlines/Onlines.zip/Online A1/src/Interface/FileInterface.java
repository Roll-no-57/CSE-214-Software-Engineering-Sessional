package Interface;

public interface FileInterface {
    public void loadDocument(String path);
    public void saveDocument(String path);
}
