package PaymentInterface;

public interface PayMethods {
    public void pay();
}
